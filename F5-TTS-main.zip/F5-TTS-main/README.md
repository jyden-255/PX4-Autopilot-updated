# Voice companion — setup & execution (MacBook Pro M4)

I haven't been able to run this myself — I don't have a GPU or internet access to
download the model in the environment I build in. Everything below is accurate to
the F5-TTS repo you sent me, but **you're the first one actually running it**, so
go through it once yourself before relying on it, and expect to troubleshoot a
little the first time.

## What this is

- `server.py` — runs on the Mac. Listens for a recorded question, gets a reply
  from Gemini, speaks it in the cloned voice with F5-TTS, sends the audio back.
- `phone_app.html` — the call-screen app, updated to record his voice and send
  it to the Mac instead of using ElevenLabs.
- Both devices must be on the **same wifi network**.

## 1. One-time setup

```bash
# In Terminal, in this folder:
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

This installs F5-TTS itself, so it may take a few minutes.

## 2. Add the voice reference clip

Put a **clean ~10-20 second clip of her talking, no background music**, in this
folder, named `ref_voice.wav`. (The original recording had music under it —
that will confuse the cloning, so trim a music-free section first. QuickTime
Player → Edit → Trim works fine, then File → Export As → Audio Only.)

## 3. Set the Gemini API key

```bash
export GEMINI_API_KEY="paste_the_real_key_here"
```

Do this in the same Terminal window/tab you'll run the server from — it doesn't
persist once you close the tab, so if you reopen Terminal later you'll need to
run this line again. Never save the actual key into `server.py` or commit it
anywhere.

## 4. Run the server

```bash
uvicorn server:app --host 0.0.0.0 --port 8000
```

Expected output looks like this:

```
Loading F5-TTS model (first run downloads weights, can take a few minutes)...
F5-TTS ready.
INFO:     Uvicorn running on http://0.0.0.0:8000
```

The **first run downloads the model weights from Hugging Face** (roughly
1-2GB) — this needs internet access and will take a few minutes depending on
your connection. After that first download it's cached locally and future
startups are fast.

Leave this Terminal window running the whole time he might use the app — this
is the "server" and it needs to stay open and awake (Mac shouldn't sleep).

## 5. Find the Mac's local IP

In a **new** Terminal tab:

```bash
ipconfig getifaddr en0
```

This prints something like `192.168.1.42`. That's the address to use next.

## 6. Point the phone app at the server

Open `phone_app.html` in a text editor, find this line near the top of the
script:

```js
const SERVER_URL = "http://YOUR_MAC_LOCAL_IP:8000/converse";
```

Replace `YOUR_MAC_LOCAL_IP` with the address from step 5, e.g.:

```js
const SERVER_URL = "http://192.168.1.42:8000/converse";
```

Also set `CALLER_NAME` and optionally `CALLER_PHOTO_URL` a bit further down,
same as before.

## 7. Get it onto the phone

For the microphone to work, this needs to load over **https**, not as a raw
local file. Easiest free option:

```bash
# drag-and-drop alternative: netlify.app/drop
```

Drag `phone_app.html` into netlify.app/drop — no signup needed — it gives you
a live https link in seconds. Save that link to the phone's home screen.

**Important:** the phone must be on the same wifi as the Mac for `SERVER_URL`
to be reachable. If he's not on the same network, this whole local-server
approach won't reach the Mac — that's the fundamental tradeoff of doing this
for free instead of paying for hosted access.

## 8. Using it

1. On the phone, tap the app icon → tap the green call button
2. Swipe/tap to answer
3. Talk — then **tap the waveform** when done talking (push-to-talk, not
   continuous listening)
4. Wait a few seconds — audio round trip is roughly 3-10 seconds depending on
   how busy the Mac is (see the latency breakdown I gave earlier)
5. Her cloned voice plays the reply
6. Repeat, or tap the red button to end

If anything fails (mic permission denied, Mac unreachable, server error), the
app quietly falls back to playing one of the real pre-recorded clips instead
of breaking.

## Troubleshooting

- **"F5-TTS ready" never prints / hangs on load** — check your internet
  connection, the first run is downloading weights.
- **Phone can't reach the server** — confirm both devices are on the same
  wifi, and that no VPN is active on either device.
- **Reply audio sounds off / robotic** — the ref clip likely still has
  background noise or music in it; re-trim `ref_voice.wav` to be cleaner.
- **CORS or "failed to fetch" in the phone browser console** — the server
  needs to be running and reachable at the exact `SERVER_URL` you set.
