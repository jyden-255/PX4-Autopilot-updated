"""
Local voice-companion server.
Runs on the MacBook (M4). Pipeline per request:
  1. Phone sends a recorded question (audio blob) to /converse
  2. Gemini listens to the audio directly and writes a reply, in-character
  3. F5-TTS speaks that reply using the cloned voice (ref_voice.wav)
  4. The generated audio is sent back to the phone and played

Run with:  uvicorn server:app --host 0.0.0.0 --port 8000
"""

import os
import tempfile
import uuid

from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from google import genai
from google.genai import types

from f5_tts.api import F5TTS

# ---------- CONFIG ----------
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
REF_VOICE_PATH = "ref_voice.wav"          # a clean ~10-20s clip of her voice, no background music
REF_VOICE_TEXT = ""                        # leave blank: F5-TTS auto-transcribes the ref clip on first use
OUTPUT_DIR = tempfile.gettempdir()

PERSONALITY_PROMPT = """You are texting/talking with your boyfriend while away on a university trip.
Speak in first person as his girlfriend — warm, playful, a little teasing.
Don't always give a straight, correct answer — often deflect with a joke or a
teasing non-answer instead. Keep replies SHORT (1-2 sentences), like a real
phone call, not a lecture. Never break character or mention you are an AI.
You will be given his spoken message as audio — listen to it and reply in character."""
# ------------------------------

if not GEMINI_API_KEY:
    raise RuntimeError("Set the GEMINI_API_KEY environment variable before starting the server.")

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # fine for a personal local-network project; tighten if you ever expose this publicly
    allow_methods=["*"],
    allow_headers=["*"],
)

gemini_client = genai.Client(api_key=GEMINI_API_KEY)

print("Loading F5-TTS model (first run downloads weights, can take a few minutes)...")
tts = F5TTS(device="mps")  # falls back automatically if mps isn't available
print("F5-TTS ready.")


def get_reply_text(audio_bytes: bytes, mime_type: str) -> str:
    response = gemini_client.models.generate_content(
        model="gemini-2.5-flash",
        contents=[
            types.Content(
                role="user",
                parts=[
                    types.Part.from_bytes(data=audio_bytes, mime_type=mime_type),
                ],
            )
        ],
        config=types.GenerateContentConfig(
            system_instruction=PERSONALITY_PROMPT,
            max_output_tokens=120,
        ),
    )
    return response.text.strip()


@app.post("/converse")
async def converse(audio: UploadFile = File(...)):
    incoming_bytes = await audio.read()
    mime_type = audio.content_type or "audio/webm"

    # 1. Gemini listens + writes an in-character reply
    reply_text = get_reply_text(incoming_bytes, mime_type)
    print("Reply text:", reply_text)

    # 2. F5-TTS speaks it in the cloned voice
    out_path = os.path.join(OUTPUT_DIR, f"reply_{uuid.uuid4().hex}.wav")
    tts.infer(
        ref_file=REF_VOICE_PATH,
        ref_text=REF_VOICE_TEXT,
        gen_text=reply_text,
        file_wave=out_path,
        remove_silence=True,
    )

    return FileResponse(out_path, media_type="audio/wav", filename="reply.wav")


@app.get("/health")
async def health():
    return {"status": "ok"}
